
export type ScenarioCategory = 'historical' | 'horror' | 'scifi' | 'fantasy' | 'mystery' | 'drama' | 'action';

export interface Scenario {
  id: string;
  category: ScenarioCategory;
  title: string;
  description: string;
  icon: string;
  color: string;
  backgroundImage: string;
  systemInstruction: string;
  initialMessage: string;
  isCustom?: boolean;
  isImported?: boolean; 
  password?: string; 
  passwordHint?: string; 
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface RecapEntry {
  id: string;
  timestamp: number;
  summaryText: string;
  coveredMessagesCount: number; // How many messages this summary covers
}

export interface ChatSessionState {
  messages: Message[];
  suggestions: string[];
  playerRole: string; 
  characterAvatars: { [characterName: string]: string }; 
  isTyping: boolean;
  summary: string; 
  novelChapters: string[]; // Store auto-generated novel chapters
  recapHistory: RecapEntry[]; // Store history of summaries
  modifiedSystemInstruction?: string; // Allow user to tweak instructions mid-game
}

export interface ExportedSession {
  version: number;
  timestamp: number;
  scenario: Scenario;
  messages: Message[];
  playerRole: string;
  characterAvatars: { [characterName: string]: string };
  summary?: string; 
  novelChapters?: string[];
  recapHistory?: RecapEntry[];
  password?: string; // If exported file is protected (Legacy/Simple UI lock)
}

export interface EncryptedExport {
  isEncrypted: true;
  data: string; // Base64 ciphertext
  iv: string;   // Base64 IV
  salt: string; // Base64 Salt
  timestamp: number;
}
