
import React from 'react';

interface SuggestionChipsProps {
  suggestions: string[];
  onSelect: (text: string) => void;
  disabled: boolean;
}

export const SuggestionChips: React.FC<SuggestionChipsProps> = ({ suggestions, onSelect, disabled }) => {
  // If no suggestions, or suggestions were not correctly parsed into an array, don't render.
  if (!suggestions || suggestions.length === 0) return null;

  return (
    <div className="w-full flex flex-col gap-3 my-4 animate-fade-in-up z-20 relative max-w-[90%] md:max-w-[75%] mx-auto">
      <div className="w-full text-center text-[10px] text-gray-500 mb-1 font-bold tracking-widest uppercase opacity-70">
        -- اختر مسارك --
      </div>
      {suggestions.map((suggestion, index) => (
        <button
          key={`${index}-${suggestion.slice(0, 10)}`}
          onClick={(e) => {
            e.preventDefault();
            if (!disabled) onSelect(suggestion);
          }}
          disabled={disabled}
          className={`
            group relative overflow-hidden text-right block w-full
            bg-gray-800/80 backdrop-blur-sm hover:bg-indigo-900/80
            border border-gray-600 hover:border-indigo-400
            text-gray-200 hover:text-white
            text-sm font-medium py-3 px-5 rounded-xl
            transition-all duration-200 transform hover:scale-[1.01] active:scale-[0.98]
            shadow-lg
          `}
        >
          <div className="flex items-center gap-3">
             <span className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs font-bold border border-indigo-500/30 shrink-0">
               {index + 1}
             </span>
             <span className="relative z-10 leading-relaxed text-right flex-1">
               {suggestion}
             </span>
          </div>
        </button>
      ))}
    </div>
  );
};
