
import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Message } from '../types';
import { parseContentAndSuggestions } from '../services/geminiService';

interface ChatMessageProps {
  message: Message;
  isLatest: boolean;
  playerRole: string; 
  characterAvatars: { [characterName: string]: string }; 
  onCharacterAvatarClick: (characterName: string, avatarUrl?: string) => void; 
  onRewind: (messageId: string) => void;
}

const getChatBubbleGradient = (str: string) => {
  const gradients = [
    'from-rose-600 to-rose-800', 
    'from-blue-600 to-blue-800', 
    'from-emerald-600 to-emerald-800', 
    'from-amber-600 to-amber-800',
    'from-violet-600 to-violet-800',
    'from-cyan-600 to-cyan-800',
    'from-fuchsia-600 to-fuchsia-800'
  ];
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return gradients[Math.abs(hash) % gradients.length];
};

const getAvatarGradient = (str: string) => {
  const gradients = [
    'from-teal-500 to-cyan-600',
    'from-red-500 to-pink-600',
    'from-purple-500 to-indigo-600',
    'from-orange-500 to-amber-600',
    'from-lime-500 to-green-600',
    'from-fuchsia-500 to-rose-600',
    'from-sky-500 to-blue-600'
  ];
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return gradients[Math.abs(hash) % gradients.length];
};

const getInitials = (name: string) => {
  const parts = name.trim().split(' ');
  if (parts.length > 1) {
    return (parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
  }
  return name.charAt(0).toUpperCase();
};

/**
 * Transforms text inside parentheses to be bold in Markdown.
 * Example: (بفزع) -> **(بفزع)**
 * Handles multiline content inside parens reasonably well by using non-greedy match.
 */
const boldParentheses = (text: string) => {
  // Regex explanation:
  // \( matches opening literal parenthesis
  // ([^)]*) captures any character that is not a closing parenthesis
  // \) matches closing literal parenthesis
  // g flag for global replacement
  // We wrap the captured group in bold markdown markers **(...)**
  return text.replace(/\(([^)]*)\)/g, '**($1)**');
};

export const ChatMessage = React.memo<ChatMessageProps>(({ 
  message, 
  isLatest,
  playerRole, 
  characterAvatars, 
  onCharacterAvatarClick,
  onRewind
}) => {
  const isUser = message.role === 'user';
  const { cleanText } = parseContentAndSuggestions(message.text);
  
  // Apply bolding to parenthesis content
  const formattedText = boldParentheses(cleanText);
  
  const lines = formattedText.split('\n').filter(line => line.trim() !== '');

  const DeleteButton = ({ className }: { className?: string }) => (
      <button 
         type="button"
         onClick={(e) => {
             e.preventDefault();
             e.stopPropagation();
             onRewind(message.id);
         }}
         className={`opacity-60 hover:opacity-100 transition-opacity bg-red-950 hover:bg-red-600 border border-red-500/50 text-red-200 hover:text-white p-2 rounded-full shadow-lg cursor-pointer z-50 flex items-center justify-center ${className}`}
         title="حذف الرسالة وما بعدها"
      >
         <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0-1-1-2-2-2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
      </button>
  );

  return (
    <div 
      className={`w-full flex flex-col gap-3 mb-8 animate-fade-in-up group relative selection:bg-none`} 
    >
      
      {/* USER MESSAGE */}
      {isUser && (
        <div className="flex flex-row-reverse items-end gap-4 self-end max-w-[90%] md:max-w-[75%] relative group/bubble">
           {/* Avatar */}
           <div className="w-11 h-11 rounded-full bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center text-white font-bold text-base shadow-lg border-2 border-emerald-400 shrink-0">
             {getInitials(playerRole)}
           </div>
           
           {/* Content Wrapper */}
           <div className="flex flex-col items-end relative">
             <span className="text-xs font-bold text-emerald-400 mb-1 px-2">({playerRole} : أنت)</span>
             <div className="bg-emerald-900/80 backdrop-blur-sm text-gray-100 px-5 py-3 rounded-2xl rounded-bl-none border border-emerald-500/30 shadow-md relative">
               <div className="prose prose-invert prose-sm leading-relaxed">
                 <ReactMarkdown>
                   {formattedText}
                 </ReactMarkdown>
               </div>
             </div>
             
             {/* Delete Button */}
             <div className="absolute top-1/2 -translate-y-1/2 -right-12 pointer-events-auto">
                 <DeleteButton />
             </div>
           </div>
        </div>
      )}

      {/* AI MESSAGE (Split into bubbles) */}
      {!isUser && (
        <>
          {lines.map((line, idx) => {
            const match = line.match(/^([^\(:]+)(?:\s*\(.*?\))?\s*:(.*)/);
            
            let isNarratorLine = false;
            let isCharacter = false;
            let content = line;
            let name = '';

            if (match) {
                 name = match[1].trim();
                 content = match[2].trim();
                 if (name === 'الراوي') isNarratorLine = true;
                 else isCharacter = true;
            } else if (line.includes('...')) {
                 isNarratorLine = true;
            }

            const animationStyle = isLatest ? { animationDelay: `${idx * 1000}ms` } : {};

            // --- NARRATOR ---
            if (isNarratorLine) {
              return (
                <div key={idx} style={animationStyle} className={`w-full flex justify-center my-2 group/bubble relative ${isLatest ? 'animate-fade-in-up' : ''}`}>
                  <div className="
                      relative w-full md:w-[90%] 
                      bg-gray-900/60 backdrop-blur-md
                      border-y border-gray-700
                      px-6 py-4 rounded-lg 
                      shadow-inner flex items-center gap-4
                  ">
                      <div className="w-11 h-11 rounded-full bg-gradient-to-br from-purple-800 to-violet-900 flex items-center justify-center text-xl shadow-lg border-2 border-purple-600 shrink-0">
                        📜
                      </div>
                      <div className="flex-1 flex flex-col">
                        <span className="text-sm text-gray-400 font-bold mb-1">الراوي</span>
                        <div className="text-gray-300 text-lg font-serif leading-loose tracking-wide">
                          <ReactMarkdown components={{ p: ({node, ...props}) => <span {...props} /> }}>
                            {content}
                          </ReactMarkdown>
                        </div>
                      </div>
                  </div>
                </div>
              );
            }

            // --- CHARACTER ---
            if (isCharacter) {
              const bubbleGradientClass = getChatBubbleGradient(name);
              const avatarGradientClass = getAvatarGradient(name);
              const initials = getInitials(name);
              const customAvatarUrl = characterAvatars[name];
              
              return (
                <div key={idx} style={animationStyle} className={`flex items-end gap-4 self-start max-w-[95%] md:max-w-[85%] mt-2 relative group/bubble ${isLatest ? 'animate-fade-in-up' : ''}`}>
                  <button 
                    onClick={(e) => { e.stopPropagation(); onCharacterAvatarClick(name, customAvatarUrl); }}
                    className={`w-11 h-11 rounded-full flex items-center justify-center text-white font-bold text-base shadow-lg border-2 border-white/20 shrink-0 overflow-hidden cursor-pointer group hover:scale-105 transition-transform`}
                    title={`معلومات ${name}`}
                  >
                    {customAvatarUrl ? (
                      <img src={customAvatarUrl} alt={name} className="w-full h-full object-cover" />
                    ) : (
                      <div className={`w-full h-full bg-gradient-to-br ${avatarGradientClass} flex items-center justify-center`}>
                        {initials}
                      </div>
                    )}
                  </button>
                  
                  <div className="flex flex-col group/bubble relative">
                    <span className="text-xs font-bold text-gray-400 mb-1 px-2">{name}</span>
                    <div 
                      className={`
                      bg-gradient-to-br ${bubbleGradientClass}
                      text-white px-5 py-3 rounded-2xl rounded-br-xl rounded-bl-none 
                      shadow-xl border border-white/10 relative
                    `}>
                      <ReactMarkdown components={{ p: ({node, ...props}) => <span {...props} /> }}>
                        {content}
                      </ReactMarkdown>
                    </div>
                  </div>
                </div>
              );
            }

            return null;
          })}
        </>
      )}
    </div>
  );
});

ChatMessage.displayName = 'ChatMessage';
