
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { SCENARIOS } from './constants';
import { Message, Scenario, ExportedSession, RecapEntry, EncryptedExport } from './types';
import { chatService, parseContentAndSuggestions } from './services/geminiService';
import { encryptData, decryptData } from './services/cryptoService';
import { ChatMessage } from './components/ChatMessage';
import { SuggestionChips } from './components/SuggestionChips';
import { ChatInput } from './components/ChatInput';
import ReactMarkdown from 'react-markdown';

const App: React.FC = () => {
  // Views: 'home' | 'chat'
  const [currentView, setCurrentView] = useState<'home' | 'chat'>('home');
  const [showSidebar, setShowSidebar] = useState(false);

  // Data
  const [scenarios, setScenarios] = useState<Scenario[]>(SCENARIOS);
  const [currentScenario, setCurrentScenario] = useState<Scenario>(SCENARIOS[0]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  
  // Advanced State (Memory)
  const [storySummary, setStorySummary] = useState<string>('');
  const [recapHistory, setRecapHistory] = useState<RecapEntry[]>([]);
  const [currentSystemInstruction, setCurrentSystemInstruction] = useState<string>('');
  
  // Security State
  const [customSectionPassword, setCustomSectionPassword] = useState<string | null>(null);
  const [importedSectionPassword, setImportedSectionPassword] = useState<string | null>(null);
  const [isCustomSectionUnlocked, setIsCustomSectionUnlocked] = useState(false);
  const [isImportedSectionUnlocked, setIsImportedSectionUnlocked] = useState(false);
  
  // Player Persona & Avatars
  const [playerRole, setPlayerRole] = useState<string>('البطل');
  const [characterAvatars, setCharacterAvatars] = useState<{ [characterName: string]: string }>({});
  
  // UI States
  const [isTyping, setIsTyping] = useState(false);
  const [stats, setStats] = useState({ sent: 0, received: 0, space: 0, stories: 0 });

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [customRole, setCustomRole] = useState('');
  const [customPlot, setCustomPlot] = useState('');
  const [isCreatingStory, setIsCreatingStory] = useState(false);

  // Recap Modal
  const [showRecapModal, setShowRecapModal] = useState(false);
  const [recapText, setRecapText] = useState('');
  const [isRecapLoading, setIsRecapLoading] = useState(false);

  // Delete Confirmation Modal
  const [deleteModal, setDeleteModal] = useState<{ show: boolean; messageId: string | null }>({ show: false, messageId: null });

  // Character Modal (Local Extraction)
  const [showCharacterModal, setShowCharacterModal] = useState(false);
  const [detectedCharacters, setDetectedCharacters] = useState<string[]>([]);
  const [editAvatarTarget, setEditAvatarTarget] = useState<string | null>(null);
  
  const [importPreviewData, setImportPreviewData] = useState<ExportedSession | null>(null);

  // Password Modals
  const [passwordModal, setPasswordModal] = useState<{
    show: boolean;
    type: 'setCustom' | 'unlockCustom' | 'setImported' | 'unlockImported' | 'unlockImportFile';
    importData?: ExportedSession | EncryptedExport; 
  }>({ show: false, type: 'unlockCustom' });
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null); 
  const [isDecrypting, setIsDecrypting] = useState(false);

  // Export Modal State
  const [exportModal, setExportModal] = useState<{ show: boolean }>({ show: false });
  const [exportTab, setExportTab] = useState<'normal' | 'encrypted'>('normal');
  const [exportPassword, setExportPassword] = useState('');
  const [isExporting, setIsExporting] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const avatarFileInputRef = useRef<HTMLInputElement>(null);

  // --- INITIALIZATION & EFFECTS ---

  useEffect(() => {
    // 1. Load Custom & Imported Scenarios
    const savedCustom = localStorage.getItem('hikaya_custom_scenarios');
    const savedImported = localStorage.getItem('hikaya_imported_scenarios');

    let allScenarios = [...SCENARIOS];
    if (savedCustom) allScenarios = [...allScenarios, ...JSON.parse(savedCustom)];
    if (savedImported) allScenarios = [...allScenarios, ...JSON.parse(savedImported)];
    
    // Deduplicate
    const uniqueScenarios = Array.from(new Map(allScenarios.map(item => [item.id, item])).values());
    setScenarios(uniqueScenarios);

    // Passwords
    setCustomSectionPassword(localStorage.getItem('hikaya_custom_section_password'));
    setImportedSectionPassword(localStorage.getItem('hikaya_imported_section_password'));
    
    // Calculate Stats
    calculateStats(uniqueScenarios);

  }, []);

  const calculateStats = (currentScenarios: Scenario[]) => {
    let sent = 0;
    let received = 0;
    let space = 0;
    for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
            space += localStorage[key].length * 2; // bytes
            if (key.startsWith('hikaya_chat_')) {
                try {
                    const data = JSON.parse(localStorage[key]);
                    if (data.messages) {
                        sent += data.messages.filter((m: Message) => m.role === 'user').length;
                        received += data.messages.filter((m: Message) => m.role === 'model').length;
                    }
                } catch {}
            }
        }
    }
    setStats({
        sent, received, 
        space: Math.round(space / 1024), 
        stories: currentScenarios.filter(s => s.isCustom && !s.isImported).length
    });
  };

  useEffect(() => {
    const custom = scenarios.filter(s => s.isCustom && !s.isImported);
    const imported = scenarios.filter(s => s.isImported);
    localStorage.setItem('hikaya_custom_scenarios', JSON.stringify(custom));
    localStorage.setItem('hikaya_imported_scenarios', JSON.stringify(imported));
    calculateStats(scenarios);
  }, [scenarios]);

  useEffect(() => {
    if (currentView === 'chat') {
        const savedChat = localStorage.getItem(`hikaya_chat_${currentScenario.id}`);
        if (savedChat) {
          const data = JSON.parse(savedChat);
          setMessages(data.messages);
          setSuggestions(data.suggestions || []);
          setPlayerRole(data.playerRole || 'البطل');
          setCharacterAvatars(data.characterAvatars || {});
          setStorySummary(data.summary || '');
          setRecapHistory(data.recapHistory || []);
          setCurrentSystemInstruction(data.modifiedSystemInstruction || currentScenario.systemInstruction);

          // Restore session with memory
          chatService.startSession(
              currentScenario, 
              data.messages, 
              data.summary || '',
              data.modifiedSystemInstruction || currentScenario.systemInstruction
          );
        } else {
          initializeChat(currentScenario);
        }
        setTimeout(scrollToBottom, 100);
    }
  }, [currentScenario.id, currentView]);

  useEffect(() => {
    if (currentView === 'chat' && messages.length > 0) {
       localStorage.setItem(`hikaya_chat_${currentScenario.id}`, JSON.stringify({ 
           messages, 
           suggestions, 
           playerRole, 
           characterAvatars,
           summary: storySummary,
           recapHistory,
           modifiedSystemInstruction: currentSystemInstruction
        }));
    }
  }, [messages, suggestions, playerRole, characterAvatars, currentScenario.id, currentView, storySummary, recapHistory, currentSystemInstruction]);

  const scrollToBottom = () => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // --- CHAT LOGIC ---

  const initializeChat = (scenario: Scenario) => {
    setMessages([]);
    const { suggestions: parsedSuggestions } = parseContentAndSuggestions(scenario.initialMessage);
    setSuggestions(parsedSuggestions.slice(0, 3)); 
    setPlayerRole(scenario.isCustom || scenario.isImported ? playerRole : 'البطل');
    setCharacterAvatars({});
    setStorySummary('');
    setRecapHistory([]);
    
    const startingContext = `${scenario.systemInstruction}\n\n[CONTEXT: The story begins with the following scene. Do not repeat it, just continue from here when the user acts.]\n${scenario.initialMessage}`;
    setCurrentSystemInstruction(startingContext);
    
    chatService.startSession(scenario, [], '', startingContext);
  };

  const checkAndCondenseMemory = async (currentMsgs: Message[], currentSum: string) => {
      if (currentMsgs.length > 25 && currentMsgs.length % 5 === 0) {
          const messagesToCondense = currentMsgs.slice(0, currentMsgs.length - 15);
          if (messagesToCondense.length > 0) {
              try {
                  const newSummary = await chatService.condenseMemory(messagesToCondense, currentSum);
                  setStorySummary(newSummary);
                  chatService.startSession(currentScenario, currentMsgs, newSummary, currentSystemInstruction);
              } catch (e) { console.error(e); }
          }
      }
  };

  // Memoized send handler to prevent unnecessary re-renders in child
  const handleSendMessage = useCallback(async (text: string) => {
    if (!text.trim() || isTyping) return;
    
    const userMsg: Message = { id: Date.now().toString(), role: 'user', text, timestamp: Date.now() };
    
    // Optimistic update
    setMessages(prev => [...prev, userMsg]);
    setSuggestions([]);
    setIsTyping(true); 

    setTimeout(scrollToBottom, 100);

    const botMsgId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, { id: botMsgId, role: 'model', text: '', timestamp: Date.now() }]);

    try {
      await chatService.sendMessageStream(text, 
        (chunk) => {
           setMessages(prev => prev.map(m => m.id === botMsgId ? { ...m, text: chunk } : m));
        },
        async (full) => {
           setIsTyping(false);
           const { suggestions: newSugg } = parseContentAndSuggestions(full);
           setSuggestions(newSugg.slice(0, 3)); 
           
           setMessages(currentMessages => {
               const updatedMessages = currentMessages.map(m => m.id === botMsgId ? { ...m, text: full } : m);
               checkAndCondenseMemory(updatedMessages, storySummary); 
               return updatedMessages;
           });
        }
      );
    } catch (error) {
      setIsTyping(false);
      setMessages(prev => prev.map(m => m.id === botMsgId ? { ...m, text: "حدث خطأ في الاتصال..." } : m));
    }
  }, [isTyping, storySummary]);

  // --- ACTIONS ---

  const handleDeleteScenario = (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      const s = scenarios.find(s => s.id === id);
      if (s?.isCustom || s?.isImported) {
          if (confirm('تحذير: ستقوم بحذف هذه القصة والمحادثة الخاصة بها للأبد. هل أنت متأكد؟')) {
              setScenarios(prev => prev.filter(scenario => scenario.id !== id));
              localStorage.removeItem(`hikaya_chat_${id}`);
              calculateStats(scenarios.filter(scenario => scenario.id !== id));
          }
      } else {
          if (confirm('هل تريد حذف المحادثة وإعادة ضبط القصة للبداية؟')) {
              localStorage.removeItem(`hikaya_chat_${id}`);
              alert('تم التصفير.');
              if (currentView === 'chat' && currentScenario.id === id) {
                 initializeChat(currentScenario);
              }
          }
      }
  };

  const requestRewind = useCallback((messageId: string) => {
      setDeleteModal({ show: true, messageId });
  }, []);

  const confirmRewind = () => {
      if (!deleteModal.messageId) return;
      
      const index = messages.findIndex(m => m.id === deleteModal.messageId);
      if (index !== -1) {
          const keptMessages = messages.slice(0, index);
          setMessages(keptMessages);
          chatService.startSession(currentScenario, keptMessages, storySummary, currentSystemInstruction);
      }
      setDeleteModal({ show: false, messageId: null });
  };

  const handleSmartRecap = async () => {
      setShowRecapModal(true);
      setIsRecapLoading(true);
      
      const messagesToSummarize = messages.slice(-20);

      if (messagesToSummarize.length < 2) {
           setRecapText("لا توجد أحداث جديدة كافية للتلخيص.");
           setIsRecapLoading(false);
           return;
      }

      try {
          const summary = await chatService.summarizeChat(messagesToSummarize);
          setRecapText(summary);
          
          setRecapHistory(prev => [...prev, {
              id: Date.now().toString(),
              timestamp: Date.now(),
              summaryText: summary,
              coveredMessagesCount: messages.length
          }]);
      } catch {
          setRecapText("فشل التذكر...");
      } finally {
          setIsRecapLoading(false);
      }
  };

  // --- CHARACTER & AVATAR LOGIC (LOCAL EXTRACTION) ---

  const handleThreeDotsClick = (e: React.MouseEvent, s: Scenario) => {
      e.stopPropagation();
      const savedChat = localStorage.getItem(`hikaya_chat_${s.id}`);
      let msgs: Message[] = [];
      let avatars = {};
      
      if (savedChat) {
          const d = JSON.parse(savedChat);
          msgs = d.messages || [];
          avatars = d.characterAvatars || {};
      } 

      setCurrentScenario(s); 
      setCharacterAvatars(avatars);
      
      const names = new Set<string>();
      if (msgs.length === 0) {
          const lines = s.initialMessage.split('\n');
          lines.forEach(l => extractNameFromLine(l, names));
      }

      msgs.forEach(m => {
          if (m.role === 'model') {
              const lines = m.text.split('\n');
              lines.forEach(l => extractNameFromLine(l, names));
          }
      });
      
      setDetectedCharacters(Array.from(names));
      setShowCharacterModal(true);
  };

  const extractNameFromLine = (line: string, namesSet: Set<string>) => {
      const match = line.match(/^([^\(:]+)(?:\s*\(.*?\))?\s*:/);
      if (match) {
          const name = match[1].trim();
          if (name !== 'الراوي' && name.length > 1 && name.length < 20) {
              namesSet.add(name);
          }
      }
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file || !editAvatarTarget) return;

      const reader = new FileReader();
      reader.onloadend = () => {
          const base64 = reader.result as string;
          setCharacterAvatars(prev => {
              const updated = { ...prev, [editAvatarTarget]: base64 };
              const key = `hikaya_chat_${currentScenario.id}`;
              const existing = localStorage.getItem(key);
              if (existing) {
                  const data = JSON.parse(existing);
                  data.characterAvatars = updated;
                  localStorage.setItem(key, JSON.stringify(data));
              }
              return updated;
          });
      };
      reader.readAsDataURL(file);
  };

  // --- IMPORT / EXPORT LOGIC ---
  
  const initiateExport = () => {
      if (messages.length === 0) return;
      setExportModal({ show: true });
      setExportTab('normal');
      setExportPassword('');
  };

  const performExport = async () => {
    const isEncrypted = exportTab === 'encrypted';
    
    if (isEncrypted && exportPassword.length < 4) {
        alert("كلمة المرور قصيرة جداً (يجب أن تكون 4 أحرف على الأقل)");
        return;
    }

    setIsExporting(true);

    // Give UI time to update to "Encrypting..." before heavy task
    await new Promise(resolve => setTimeout(resolve, 100));

    try {
        const rawData: ExportedSession = {
            version: 1, timestamp: Date.now(), scenario: currentScenario,
            messages, playerRole, characterAvatars, summary: storySummary,
            recapHistory
        };

        let finalData: ExportedSession | EncryptedExport = rawData;
        
        // Generate Date-based Filename: YYYY-MM-DD_HH-MM-SS
        const now = new Date();
        const dateStr = now.getFullYear() + "-" +
                        String(now.getMonth() + 1).padStart(2, '0') + "-" +
                        String(now.getDate()).padStart(2, '0') + "_" +
                        String(now.getHours()).padStart(2, '0') + "-" +
                        String(now.getMinutes()).padStart(2, '0') + "-" +
                        String(now.getSeconds()).padStart(2, '0');
        
        let fileName = `${dateStr}`;

        if (isEncrypted) {
            try {
                finalData = await encryptData(rawData, exportPassword);
                fileName += "_encrypted";
            } catch (cryptoError: any) {
                console.error(cryptoError);
                let msg = "فشل التشفير.";
                if (cryptoError.message && cryptoError.message.includes("secure context")) {
                   msg += " يجب استخدام HTTPS أو Localhost.";
                }
                alert(msg);
                setIsExporting(false);
                return; // Stop here if encryption fails
            }
        }

        const blob = new Blob([JSON.stringify(finalData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); 
        a.href = url;
        a.download = `${fileName}.json`;
        document.body.appendChild(a); 
        a.click(); 
        document.body.removeChild(a);
        
        // Slight delay to allow download to start before closing modal
        setTimeout(() => setExportModal({ show: false }), 500);

    } catch (e) {
        console.error(e);
        alert("حدث خطأ غير متوقع أثناء التصدير.");
    } finally {
        setIsExporting(false);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target?.result as string);
        
        if (json.isEncrypted) {
            setPasswordModal({ show: true, type: 'unlockImportFile', importData: json });
        } else {
            // Standard check for legacy password protection (simple lock, not encryption)
            if (json.password) {
                // This 'password' field inside the JSON is the old insecure way, but we treat it same flow
                setPasswordModal({ show: true, type: 'unlockImportFile', importData: json });
            } else {
                setImportPreviewData(json);
            }
        }
      } catch (err) { alert('ملف تالف أو غير صالح'); }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };
  
  const handleConfirmImport = () => {
    if (!importPreviewData) return;
    const data = importPreviewData;
    const uniqueId = `imported_${Date.now()}`;
    const importedScenario: Scenario = { 
        ...data.scenario, id: uniqueId, isCustom: false, isImported: true 
    };
    setScenarios(prev => [...prev, importedScenario]);
    localStorage.setItem(`hikaya_chat_${uniqueId}`, JSON.stringify({ 
        messages: data.messages, 
        playerRole: data.playerRole || 'البطل', 
        characterAvatars: data.characterAvatars || {},
        summary: data.summary || '',
        recapHistory: data.recapHistory || [],
        modifiedSystemInstruction: data.scenario.systemInstruction
    }));
    setImportPreviewData(null);
    alert('تم الاستيراد بنجاح');
  };

  // --- PASSWORDS & DECRYPTION ---

  const handlePasswordSubmit = async () => {
      const { type, importData } = passwordModal;
      setPasswordError(null);
      
      if (type === 'unlockImportFile' && importData) {
          // Check if it's actually an encrypted file
          if ('isEncrypted' in importData && importData.isEncrypted) {
              setIsDecrypting(true);
              try {
                  // Small delay to show spinner UI
                  await new Promise(r => setTimeout(r, 100));
                  const decryptedSession = await decryptData(importData as EncryptedExport, passwordInput);
                  setImportPreviewData(decryptedSession);
                  closePassModal();
              } catch (error) {
                  setPasswordError("كلمة المرور خاطئة أو الملف تالف");
              } finally {
                  setIsDecrypting(false);
              }
          } 
          // Legacy insecure password check
          else if ('password' in importData && importData.password) {
              if (passwordInput === importData.password) {
                  setImportPreviewData(importData as ExportedSession);
                  closePassModal();
              } else {
                  setPasswordError("كلمة السر خاطئة للملف");
              }
          }
          return;
      }

      if (type.includes('set')) {
          if (passwordInput.length < 4) { setPasswordError('4 أحرف على الأقل'); return; }
          if (type === 'setCustom') {
              localStorage.setItem('hikaya_custom_section_password', passwordInput);
              setCustomSectionPassword(passwordInput);
              setIsCustomSectionUnlocked(true);
          } else if (type === 'setImported') {
              localStorage.setItem('hikaya_imported_section_password', passwordInput);
              setImportedSectionPassword(passwordInput);
              setIsImportedSectionUnlocked(true);
          } 
          closePassModal();
      } else {
          // Unlock Sections
          let success = false;
          if (type === 'unlockCustom' && passwordInput === customSectionPassword) {
              setIsCustomSectionUnlocked(true); success = true;
          } else if (type === 'unlockImported' && passwordInput === importedSectionPassword) {
              setIsImportedSectionUnlocked(true); success = true;
          }
          if (success) closePassModal();
          else setPasswordError("كلمة السر خاطئة");
      }
  };

  const closePassModal = () => {
      setPasswordModal({ show: false, type: 'unlockCustom' });
      setPasswordInput('');
      setPasswordError(null);
      setIsDecrypting(false);
  };

  // --- RENDER ---

  const renderScenarioCard = (s: Scenario) => (
      <div 
        key={s.id}
        onClick={() => { setCurrentScenario(s); setCurrentView('chat'); }}
        className="relative group overflow-hidden rounded-2xl border border-gray-700 bg-gray-900/60 backdrop-blur-md cursor-pointer hover:border-indigo-500/50 min-w-[320px] w-[320px] h-72 shrink-0 snap-center transition-all"
      >
        <div className="p-5 flex flex-col h-full">
            <div className="flex justify-between mb-3">
                 <div className="text-4xl">{s.icon}</div>
                 <div className="text-xs bg-gray-800 px-2 py-1 rounded">{s.category}</div>
            </div>
            <h3 className={`font-bold text-xl truncate ${s.color} mb-2`}>{s.title}</h3>
            <p className="text-sm text-gray-400 line-clamp-2 mb-4">{s.description}</p>

            <div className="mt-auto flex justify-between items-center border-t border-gray-700/50 pt-3" onClick={e => e.stopPropagation()}>
                 <button onClick={(e) => handleThreeDotsClick(e, s)} className="p-2 bg-gray-800 rounded hover:bg-gray-700">•••</button>
                 <button onClick={(e) => handleDeleteScenario(e, s.id)} className="text-xs text-red-400 hover:bg-red-900/20 px-3 py-1 rounded border border-red-900/30">
                    {(s.isCustom || s.isImported) ? 'حذف نهائي' : 'تصفير'}
                 </button>
            </div>
        </div>
      </div>
  );

  return (
    <div className="h-screen font-sans bg-gray-950 text-gray-100 overflow-hidden relative">
        <div className="fixed inset-0 z-0 opacity-20 bg-cover bg-center" style={{ backgroundImage: currentView === 'chat' ? `url(${currentScenario.backgroundImage})` : 'none' }} />

        {/* SIDEBAR */}
        <div className={`fixed inset-y-0 right-0 z-[400] w-72 bg-gray-900 border-l border-gray-700 transform transition-transform duration-300 ${showSidebar ? 'translate-x-0' : 'translate-x-full'} shadow-2xl p-6 flex flex-col`}>
            <button onClick={() => setShowSidebar(false)} className="self-end text-gray-400 hover:text-white mb-6">✕ إغلاق</button>
            <h2 className="text-2xl font-bold mb-6 text-indigo-400">الإحصائيات</h2>
            <div className="space-y-4 mb-8">
                <div className="bg-gray-800 p-3 rounded-lg flex justify-between"><span>الرسائل المرسلة:</span><span className="font-bold">{stats.sent}</span></div>
                <div className="bg-gray-800 p-3 rounded-lg flex justify-between"><span>الرسائل المستلمة:</span><span className="font-bold">{stats.received}</span></div>
                <div className="bg-gray-800 p-3 rounded-lg flex justify-between"><span>القصص المنشأة:</span><span className="font-bold">{stats.stories}</span></div>
                <div className="bg-gray-800 p-3 rounded-lg flex justify-between"><span>المساحة:</span><span className="font-bold text-amber-500">{stats.space} KB</span></div>
            </div>
        </div>

        {/* --- HOME VIEW --- */}
        {currentView === 'home' && (
            <div className="relative z-10 h-full overflow-y-auto p-4 md:p-8">
                <div className="flex justify-between items-center mb-12">
                     <div className="flex items-center gap-4">
                        <span className="text-4xl">🎭</span>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-400 to-pink-400 bg-clip-text text-transparent">حكاية AI</h1>
                     </div>
                     <button onClick={() => setShowSidebar(true)} className="p-3 bg-gray-800 rounded-xl hover:bg-gray-700">☰</button>
                </div>
                <div className="flex gap-4 mb-8 justify-end">
                     <input type="file" accept=".json" ref={fileInputRef} hidden onChange={handleFileSelect} />
                     <button onClick={() => fileInputRef.current?.click()} className="px-6 py-3 bg-gray-800 rounded-xl border border-gray-600">📥 استيراد</button>
                     <button onClick={() => setShowCreateModal(true)} className="px-6 py-3 bg-indigo-600 rounded-xl font-bold">✨ قصة جديدة</button>
                </div>
                {/* Official */}
                <div className="mb-12">
                    <h2 className="text-2xl font-bold mb-4 px-4 border-r-4 border-indigo-500">قصص حكاية</h2>
                    <div className="flex overflow-x-auto gap-6 px-4 pb-4">{scenarios.filter(s => !s.isCustom && !s.isImported).map(renderScenarioCard)}</div>
                </div>
                {/* Custom */}
                <div className="mb-12">
                     <div className="flex justify-between items-center px-4 mb-4">
                        <h2 className="text-2xl font-bold border-r-4 border-amber-500 px-2">قصصي الخاصة</h2>
                        <button onClick={() => {
                            if (customSectionPassword && !isCustomSectionUnlocked) setPasswordModal({show:true, type:'unlockCustom'});
                            else if (customSectionPassword) setIsCustomSectionUnlocked(false);
                            else setPasswordModal({show:true, type:'setCustom'});
                        }} className="text-sm text-amber-400">{customSectionPassword ? (isCustomSectionUnlocked ? 'قفل القسم 🔓' : 'فتح القسم 🔒') : 'تعيين حماية'}</button>
                     </div>
                     {customSectionPassword && !isCustomSectionUnlocked ? (
                         <div className="text-center p-12 bg-gray-900/50 rounded-xl border border-dashed border-gray-700 text-gray-400">القسم مقفل 🔒</div>
                     ) : (
                         <div className="flex overflow-x-auto gap-6 px-4 pb-4">{scenarios.filter(s => s.isCustom && !s.isImported).map(renderScenarioCard)}</div>
                     )}
                </div>
                {/* Imported */}
                <div className="mb-12">
                    <div className="flex justify-between items-center px-4 mb-4">
                        <h2 className="text-2xl font-bold border-r-4 border-blue-500 px-2">قصص مستوردة</h2>
                        <button onClick={() => {
                            if (importedSectionPassword && !isImportedSectionUnlocked) setPasswordModal({show:true, type:'unlockImported'});
                            else if (importedSectionPassword) setIsImportedSectionUnlocked(false);
                            else setPasswordModal({show:true, type:'setImported'});
                        }} className="text-sm text-blue-400">{importedSectionPassword ? (isImportedSectionUnlocked ? 'قفل القسم 🔓' : 'فتح القسم 🔒') : 'تعيين حماية'}</button>
                    </div>
                    {importedSectionPassword && !isImportedSectionUnlocked ? (
                         <div className="text-center p-12 bg-gray-900/50 rounded-xl border border-dashed border-gray-700 text-gray-400">القسم مقفل 🔒</div>
                    ) : (
                        <div className="flex overflow-x-auto gap-6 px-4 pb-4">{scenarios.filter(s => s.isImported).map(renderScenarioCard)}</div>
                    )}
                </div>
            </div>
        )}

        {/* --- CHAT VIEW --- */}
        {currentView === 'chat' && (
            <div className="flex flex-col h-full relative z-10 max-w-4xl mx-auto">
                <div className="h-16 flex items-center justify-between px-4 bg-gray-900/90 border-b border-gray-800">
                    <div className="flex items-center gap-3">
                        <button onClick={() => setCurrentView('home')} className="text-gray-400 hover:text-white">➜</button>
                        <h1 className="font-bold truncate max-w-[150px]">{currentScenario.title}</h1>
                    </div>
                    <div className="flex gap-2">
                        <button onClick={handleSmartRecap} className="p-2 bg-indigo-900/20 text-indigo-400 rounded hover:bg-indigo-900/40">🧠</button>
                         <button onClick={initiateExport} className="p-2 bg-blue-900/20 text-blue-400 rounded hover:bg-blue-900/40" title="تصدير">💾</button>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4 pb-2">
                    {messages.length === 0 && <div className="text-center text-gray-600 mt-20">ابدأ القصة بكتابة أول رد...</div>}
                    {messages.map((m, i) => (
                        <ChatMessage 
                            key={m.id} message={m} isLatest={i === messages.length - 1} 
                            playerRole={playerRole} characterAvatars={characterAvatars} 
                            onCharacterAvatarClick={(name, url) => { setEditAvatarTarget(name); setShowCharacterModal(true); }}
                            onRewind={requestRewind}
                        />
                    ))}
                    {isTyping && <div className="text-center text-gray-500 text-xs animate-pulse">يكتب...</div>}
                    {!isTyping && <SuggestionChips suggestions={suggestions} onSelect={(t) => handleSendMessage(t)} disabled={isTyping} />}
                    <div ref={messagesEndRef} />
                </div>

                <div className="p-4 bg-gray-950/90 pb-6">
                    <ChatInput onSend={handleSendMessage} disabled={isTyping} />
                </div>
            </div>
        )}

        {/* --- MODALS --- */}
        
        {/* Delete Confirmation Modal */}
        {deleteModal.show && (
            <div className="fixed inset-0 z-[500] flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm animate-pop-in">
                <div className="bg-gray-900 p-6 rounded-2xl w-full max-w-sm border border-red-900/50 shadow-2xl">
                    <div className="text-center mb-6">
                        <div className="w-16 h-16 bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4 text-red-500 text-3xl">⚠️</div>
                        <h3 className="text-xl font-bold text-white mb-2">تأكيد العودة بالزمن</h3>
                        <p className="text-gray-400 text-sm leading-relaxed">
                            هل أنت متأكد من رغبتك في حذف هذه الرسالة وكل ما تبعها؟
                            <br />
                            <span className="text-red-400 font-bold">هذا الإجراء لا يمكن التراجع عنه!</span>
                        </p>
                    </div>
                    <div className="flex gap-3">
                        <button 
                            onClick={() => setDeleteModal({show: false, messageId: null})} 
                            className="flex-1 py-3 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-xl transition-colors font-medium"
                        >
                            إلغاء
                        </button>
                        <button 
                            onClick={confirmRewind} 
                            className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl transition-colors font-bold shadow-lg shadow-red-900/20"
                        >
                            نعم، احذف
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* Import Preview Modal */}
        {importPreviewData && (
             <div className="fixed inset-0 z-[350] flex items-center justify-center bg-black/90 p-4">
                 <div className="bg-gray-900 w-full max-w-lg p-6 rounded-2xl border border-blue-500/50 relative">
                     <h3 className="text-xl font-bold mb-4 text-blue-400 text-center">معاينة الاستيراد</h3>
                     <div className="bg-gray-800 rounded p-4 mb-4">
                        <div className="font-bold text-lg mb-2">{importPreviewData.scenario.title}</div>
                        <div className="text-sm text-gray-400 mb-2">{importPreviewData.scenario.description}</div>
                        <div className="text-xs text-gray-500">عدد الرسائل: {importPreviewData.messages.length}</div>
                     </div>
                     <div className="flex gap-3">
                         <button onClick={() => setImportPreviewData(null)} className="flex-1 py-2 bg-gray-700 rounded">إلغاء</button>
                         <button onClick={handleConfirmImport} className="flex-1 py-2 bg-blue-600 rounded font-bold">تأكيد الاستيراد</button>
                     </div>
                 </div>
             </div>
        )}
        
        {/* Export Options Modal - NEW REDESIGN */}
        {exportModal.show && (
             <div className="fixed inset-0 z-[350] flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm">
                 <div className="bg-gray-900 w-full max-w-md p-6 rounded-2xl border border-blue-900 shadow-2xl animate-pop-in">
                     <div className="flex items-center gap-3 mb-6 text-blue-400 justify-center">
                         <span className="text-3xl">💾</span>
                         <h3 className="text-2xl font-bold">تصدير المحادثة</h3>
                     </div>

                     <div className="flex gap-2 mb-6">
                        <button 
                            onClick={() => setExportTab('normal')}
                            className={`flex-1 py-3 rounded-xl border transition-all duration-200 font-bold ${exportTab === 'normal' ? 'bg-blue-600 text-white border-blue-400 shadow-lg' : 'bg-gray-800 text-gray-400 border-gray-700 hover:bg-gray-700'}`}
                        >
                           ملف عادي
                        </button>
                        <button 
                             onClick={() => setExportTab('encrypted')}
                             className={`flex-1 py-3 rounded-xl border transition-all duration-200 font-bold ${exportTab === 'encrypted' ? 'bg-indigo-600 text-white border-indigo-400 shadow-lg' : 'bg-gray-800 text-gray-400 border-gray-700 hover:bg-gray-700'}`}
                        >
                           ملف مشفر 🔒
                        </button>
                     </div>
                     
                     {exportTab === 'encrypted' && (
                         <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700 mb-6 animate-fade-in-up">
                             <div className="text-xs text-indigo-300 mb-2 text-center font-bold">قم بتعيين كلمة مرور للملف</div>
                             <input 
                                type="password"
                                placeholder="******"
                                className="w-full bg-gray-950 border border-gray-600 rounded-lg p-3 outline-none focus:border-indigo-500 transition-all text-center tracking-widest text-lg"
                                value={exportPassword}
                                onChange={e => setExportPassword(e.target.value)}
                                autoFocus
                             />
                             <p className="text-[10px] text-gray-500 mt-2 text-center">تنبيه: لا يمكن استعادة الملف إذا فقدت كلمة المرور.</p>
                         </div>
                     )}

                     {exportTab === 'normal' && (
                        <div className="bg-gray-800/30 p-4 rounded-xl border border-gray-700/50 mb-6 text-center text-sm text-gray-400 animate-fade-in-up">
                            سيتم تحميل ملف JSON يحتوي على سجل المحادثة بالكامل. يمكنك استيراده لاحقاً في أي وقت.
                        </div>
                     )}

                     <div className="flex gap-3">
                         <button onClick={() => setExportModal({ show: false })} className="flex-1 py-3 bg-gray-800 hover:bg-gray-700 rounded-xl transition-colors font-medium text-gray-300">إلغاء</button>
                         <button 
                            onClick={performExport} 
                            disabled={isExporting}
                            className={`flex-1 py-3 text-white font-bold rounded-xl shadow-lg transition-colors flex justify-center items-center ${exportTab === 'encrypted' ? 'bg-indigo-600 hover:bg-indigo-500' : 'bg-blue-600 hover:bg-blue-500'}`}
                         >
                            {isExporting 
                                ? (exportTab === 'encrypted' ? 'جاري التشفير...' : 'جاري التحميل...') 
                                : (exportTab === 'encrypted' ? 'تشفير وحفظ' : 'تحميل الملف')
                            }
                         </button>
                     </div>
                 </div>
             </div>
        )}

        {/* Character Info (Local) */}
        {showCharacterModal && (
            <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 p-4">
                <div className="bg-gray-900 w-full max-w-md p-6 rounded-2xl border border-gray-700 animate-pop-in">
                    <h3 className="text-xl font-bold mb-4 text-indigo-400">الشخصيات و الأفتار</h3>
                    {editAvatarTarget && (
                        <div className="mb-6 p-4 bg-gray-800 rounded-xl border border-indigo-500/30">
                            <h4 className="font-bold mb-2">تغيير صورة: {editAvatarTarget}</h4>
                            <div className="flex gap-2 items-center">
                                <input type="text" placeholder="رابط URL..." className="flex-1 bg-gray-900 border border-gray-700 p-2 rounded" onChange={e => setCharacterAvatars(prev => ({...prev, [editAvatarTarget]: e.target.value}))} />
                                <span className="text-xs text-gray-500">أو</span>
                                <input type="file" accept="image/*" ref={avatarFileInputRef} hidden onChange={handleAvatarUpload} />
                                <button onClick={() => avatarFileInputRef.current?.click()} className="p-2 bg-indigo-600 rounded">📂 رفع</button>
                            </div>
                        </div>
                    )}
                    <div className="max-h-60 overflow-y-auto space-y-3">
                        {detectedCharacters.length === 0 && <p className="text-gray-500 text-center">لا توجد شخصيات مكتشفة بعد.</p>}
                        {detectedCharacters.map((name, i) => (
                             <div key={i} className="flex justify-between items-center p-2 bg-gray-800 rounded">
                                <div className="font-bold">{name}</div>
                                <button onClick={() => setEditAvatarTarget(name)} className="text-xs bg-gray-700 px-2 py-1 rounded">تعديل الصورة</button>
                             </div>
                        ))}
                    </div>
                    <button onClick={() => { setShowCharacterModal(false); setEditAvatarTarget(null); }} className="mt-4 w-full py-2 bg-gray-800 rounded">إغلاق</button>
                </div>
            </div>
        )}
        
        {/* Recap Modal */}
        {showRecapModal && (
            <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 p-4">
                <div className="bg-gray-900 w-full max-w-md p-6 rounded-2xl border border-gray-700 animate-pop-in flex flex-col max-h-[80vh]">
                    <h3 className="text-xl font-bold mb-4 text-indigo-400">سجل التذكير</h3>
                    
                    {/* History List */}
                    <div className="flex-1 overflow-y-auto mb-4 space-y-4 pr-2">
                        {recapHistory.slice().reverse().map((entry) => (
                            <div key={entry.id} className="bg-gray-800 p-3 rounded-lg border border-gray-700">
                                <div className="text-xs text-gray-500 mb-1">{new Date(entry.timestamp).toLocaleTimeString('ar-EG')}</div>
                                <div className="text-sm text-gray-300"><ReactMarkdown>{entry.summaryText}</ReactMarkdown></div>
                            </div>
                        ))}
                        {recapHistory.length === 0 && !recapText && <p className="text-gray-500 text-center py-4">لا يوجد سجل تذكير.</p>}
                        
                        {/* Current Loading/Result */}
                        {isRecapLoading && <p className="animate-pulse text-center">جاري تحليل آخر 20 رسالة...</p>}
                        {recapText && !isRecapLoading && (
                             <div className="bg-indigo-900/20 p-3 rounded-lg border border-indigo-500/50 mt-2">
                                <div className="text-xs text-indigo-400 mb-1">الآن:</div>
                                <div className="text-sm text-gray-200"><ReactMarkdown>{recapText}</ReactMarkdown></div>
                             </div>
                        )}
                    </div>

                    <button onClick={handleSmartRecap} disabled={isRecapLoading} className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 rounded font-bold mb-2 shadow-lg">توليد لمحة جديدة (آخر 20 رسالة)</button>
                    <button onClick={() => { setShowRecapModal(false); setRecapText(''); }} className="w-full py-2 bg-gray-800 rounded">إغلاق</button>
                </div>
            </div>
        )}

        {/* Password Prompt Modal */}
        {passwordModal.show && (
            <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/90 p-4">
                <div className="bg-gray-900 p-8 rounded-xl w-full max-w-sm border border-gray-700">
                    <h3 className="text-xl font-bold mb-4 text-center">🔐 {isDecrypting ? 'جاري فك التشفير...' : 'الحماية'}</h3>
                    {!isDecrypting && (
                        <>
                            <input type="password" autoFocus className="w-full bg-black/50 border border-gray-600 rounded p-3 text-center mb-2" placeholder="كلمة المرور" value={passwordInput} onChange={e => {setPasswordInput(e.target.value); setPasswordError(null);}} onKeyDown={e => e.key === 'Enter' && handlePasswordSubmit()} />
                            {passwordError && <p className="text-red-400 text-sm text-center mb-2">{passwordError}</p>}
                            <div className="flex gap-2">
                                <button onClick={closePassModal} className="flex-1 py-2 bg-gray-800 rounded">إلغاء</button>
                                <button onClick={handlePasswordSubmit} className="flex-1 py-2 bg-indigo-600 rounded">تأكيد</button>
                            </div>
                        </>
                    )}
                    {isDecrypting && (
                        <div className="flex justify-center p-4">
                            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-500"></div>
                        </div>
                    )}
                </div>
            </div>
        )}
        
        {/* Create Story Modal */}
        {showCreateModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur p-4">
          <div className="glass-panel w-full max-w-lg p-8 rounded-2xl shadow-2xl border border-gray-600/50 animate-pop-in">
             <div className="flex items-center gap-2 mb-6">
                <span className="text-2xl">✨</span>
                <h3 className="text-2xl font-bold text-white">صمم مغامرتك</h3>
             </div>
             
             <div className="space-y-4">
               <div>
                  <label className="block text-sm text-gray-400 mb-1">أنت مين؟ (دورك في القصة)</label>
                  <input 
                    type="text"
                    className="w-full bg-black/40 border border-gray-600 rounded-xl p-3 text-white focus:border-indigo-500 outline-none transition-colors"
                    placeholder="مثال: قرصان فضاء، طالبة سحر، محقق خاص..."
                    value={customRole}
                    onChange={e => setCustomRole(e.target.value)}
                  />
               </div>
               
               <div>
                  <label className="block text-sm text-gray-400 mb-1">إيه الحكاية؟ (الفكرة الأساسية للقصة)</label>
                  <textarea 
                    className="w-full h-24 bg-black/40 border border-gray-600 rounded-xl p-3 text-white focus:border-indigo-500 outline-none transition-colors"
                    placeholder="مثال: البحث عن الكنز المفقود في كوكب المريخ..."
                    value={customPlot}
                    onChange={e => setCustomPlot(e.target.value)}
                  />
               </div>
             </div>

             <div className="flex justify-end gap-3 mt-6">
               <button onClick={() => setShowCreateModal(false)} className="px-4 py-2 text-gray-400 hover:text-white">إلغاء</button>
               <button 
                 onClick={async () => {
                     if(!customRole || !customPlot) return;
                     setIsCreatingStory(true);
                     try {
                        const s = await chatService.createCustomScenario(customRole, customPlot);
                        setScenarios(prev => [...prev, s]);
                        setPlayerRole(customRole);
                        setCurrentScenario(s);
                        setCurrentView('chat');
                        setShowCreateModal(false);
                        setCustomRole(''); setCustomPlot('');
                     } catch(e) { alert('فشل الإنشاء'); } 
                     finally { setIsCreatingStory(false); }
                 }} 
                 disabled={isCreatingStory}
                 className="bg-indigo-600 hover:bg-indigo-500 px-6 py-2 rounded-xl text-white font-bold transition-all shadow-lg shadow-indigo-900/50 flex items-center gap-2"
               >
                 {isCreatingStory ? 'جاري التصميم...' : 'بدء المغامرة'}
               </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
