
import { GoogleGenAI, Chat, Type } from "@google/genai";
import { Scenario, Message } from "../types";

export const parseContentAndSuggestions = (fullText: string): { cleanText: string, suggestions: string[] } => {
  const suggestionRegex = /<suggestions>([\s\S]*?)<\/suggestions>/i;
  
  let cleanText = fullText;
  let suggestions: string[] = [];

  // Parse suggestions
  const suggestionMatch = cleanText.match(suggestionRegex);
  if (suggestionMatch) {
    cleanText = cleanText.replace(suggestionMatch[0], '').trim();
    if (suggestionMatch[1]) {
      const rawSuggestions = suggestionMatch[1].trim();
      
      // Improved Parsing Logic
      // 1. Try splitting by Pipe '|'
      if (rawSuggestions.includes('|')) {
        suggestions = rawSuggestions.split('|');
      } 
      // 2. Try splitting by inline numbered lists (e.g., "1. Go left 2. Go right")
      // This regex looks for a digit followed by a dot or paren, ensuring it's not part of a sentence.
      else if (/\d+[\.)]\s+/.test(rawSuggestions)) {
         // Split by the number pattern, but filter out empty strings
         suggestions = rawSuggestions.split(/\d+[\.)]\s+/).filter(s => s.trim().length > 0);
         // If that resulted in just one big string (failed split), fall back to newlines
         if (suggestions.length === 1 && rawSuggestions.includes('\n')) {
             suggestions = rawSuggestions.split('\n');
         }
      }
      // 3. Fallback to newlines
      else if (rawSuggestions.includes('\n')) {
        suggestions = rawSuggestions.split('\n');
      }
      // 4. Last resort: just one item
      else {
        suggestions = [rawSuggestions];
      }

      suggestions = suggestions
        .map(s => s.trim())
        .filter(s => s.length > 0)
        .map(s => s.replace(/^[-*•]\s*/, '')); // Clean bullet points if any
    }
  }

  // Fallback cleanup
  cleanText = cleanText.replace(/Suggestions:.*$/i, '').trim();

  return { cleanText, suggestions };
};

export class ChatService {
  private client: GoogleGenAI;
  private chatSession: Chat | null = null;
  private currentModel: string = 'gemini-3-flash-preview'; 

  constructor() {
    this.client = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  startSession(scenario: Scenario, historyMessages: any[] = [], currentSummary: string = '', overrideInstruction?: string) {
    // 1. Prepare System Instruction with Memory & Overrides
    let baseInstruction = overrideInstruction || scenario.systemInstruction;
    
    let enhancedSystemInstruction = `
      ${baseInstruction}

      IMPORTANT: When characters speak, output format MUST be: "CharacterName: Dialogue".
      If a character is whispering or shouting, do NOT put that in the name. 
      Incorrect: "Ahmed (whispering): hello"
      Correct: "Ahmed: (whispering) hello"
    `;
    
    if (currentSummary) {
      enhancedSystemInstruction += `
      \n=== ذاكرة الأحداث السابقة (Long-Term Memory) ===
      فيما يلي ملخص للأحداث التي وقعت سابقاً. يجب عليك أخذها في الاعتبار للحفاظ على السياق:
      ${currentSummary}
      ===============================================
      `;
    }

    const recentHistory = historyMessages.slice(-20).map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));
    
    this.chatSession = this.client.chats.create({
      model: this.currentModel, 
      config: {
        systemInstruction: enhancedSystemInstruction,
        temperature: 0.9, 
        maxOutputTokens: 8192, 
      },
      history: recentHistory.length > 0 ? recentHistory : undefined
    });
  }

  async sendMessageStream(
    message: string, 
    onChunk: (text: string) => void,
    onComplete: (fullText: string) => void
  ) {
    if (!this.chatSession) {
      throw new Error("Chat session not initialized");
    }

    try {
      const result = await this.chatSession.sendMessageStream({
        message: message,
      });

      let fullText = "";

      for await (const chunk of result) {
        const text = chunk.text;
        if (text) {
          fullText += text;
          onChunk(fullText); 
        }
      }
      onComplete(fullText);
    } catch (error) {
      console.error("Error sending message:", error);
      throw error;
    }
  }

  async condenseMemory(oldMessages: Message[], existingSummary: string): Promise<string> {
    if (oldMessages.length === 0) return existingSummary;

    const chatLog = oldMessages.map(m => `${m.role === 'user' ? 'البطل' : 'الراوي'}: ${m.text}`).join('\n');
    
    const prompt = existingSummary 
      ? `لديك ملخص سابق: "${existingSummary}".
         وأحداث جديدة:
         ${chatLog}
         
         ادمج الأحداث الجديدة مع الملخص السابق لتكوين ملخص شامل ومحدث.`
      : `لخص أحداث القصة التالية في فقرة واحدة مركزة لتكون ذاكرة للذكاء الاصطناعي:
         ${chatLog}`;

    try {
      const response = await this.client.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      return response.text || existingSummary;
    } catch (e) {
      console.error("Memory condensation failed", e);
      return existingSummary;
    }
  }

  async createCustomScenario(role: string, plot: string): Promise<Scenario> {
    try {
      const response = await this.client.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Create a creative RPG scenario where user plays as: "${role}", plot: "${plot}".
        Return JSON.
        fields: title, description, icon, color (tailwind), backgroundImageKeyword, initialMessage (Format: "الراوي: ...\n\nChar: ..."), category, firstCharacterName.
        `,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    icon: { type: Type.STRING },
                    color: { type: Type.STRING },
                    backgroundImageKeyword: { type: Type.STRING },
                    initialMessage: { type: Type.STRING },
                    category: { type: Type.STRING },
                    firstCharacterName: { type: Type.STRING }
                }
            }
        }
      });

      let text = response.text || "{}";
      text = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const data = JSON.parse(text);

      return {
        id: `custom-${Date.now()}`,
        isCustom: true,
        backgroundImage: `https://source.unsplash.com/1600x900/?${encodeURIComponent(data.backgroundImageKeyword)}`, 
        systemInstruction: `
        أنت مدير لعبة (Game Master). المستخدم: ${role}. القصة: ${plot}.
        القواعد:
        1. ابدأ بـ "الراوي: [وصف]".
        2. ثم "[الاسم]: [حوار]".
        3. <suggestions>3 خيارات بصيغة المتكلم</suggestions>.
        `,
        ...data
      };
    } catch (error: any) {
      throw new Error("فشل إنشاء القصة.");
    }
  }

  async generateNovelChapter(messages: Message[]): Promise<string> {
    const chatLog = messages.map(m => `${m.role === 'user' ? 'البطل' : 'الراوي'}: ${m.text}`).join('\n');
    const response = await this.client.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `حول هذا الجزء من المحادثة إلى فصل روائي قصير يكمل ما قبله.
        
        السجل:
        ${chatLog}
        
        اكتب الفصل مباشرة:`
    });
    return response.text || "";
  }

  async generateNovelFull(chapters: string[], currentMessages: Message[]): Promise<string> {
     // Concatenate chapters + convert current buffer
     let fullNovel = chapters.join('\n\n***\n\n');
     if (currentMessages.length > 0) {
         const lastChapter = await this.generateNovelChapter(currentMessages);
         fullNovel += '\n\n***\n\n' + lastChapter;
     }
     return fullNovel;
  }

  async summarizeChat(messages: Message[]): Promise<string> {
    const chatLog = messages.map(m => `${m.role === 'user' ? 'أنا' : 'الراوي'}: ${m.text}`).join('\n');
    const response = await this.client.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `إعمل ملخص سريع للي حصل في الرسائل دي باللهجة المصرية العامية الظريفة (زي الحكاوي على القهوة كدا) عشان المستخدم يفتكر هو وقف فين وما ينساش التفاصيل:
        
        ${chatLog}`
    });
    return response.text || "";
  }

  async getCharacterDescription(characterName: string, chatHistory: Message[]): Promise<string> {
    const context = chatHistory.slice(-10).map(m => m.text).join('\n'); 
    const response = await this.client.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `صف الشخصية "${characterName}" باختصار بناءً على:
      ${context}`,
    });
    return response.text || "";
  }
  
  async getCharactersList(chatHistory: Message[]): Promise<{name: string, bio: string}[]> {
      // Analyze chat to find characters
      const context = chatHistory.slice(-30).map(m => m.text).join('\n');
      try {
        const response = await this.client.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Extract main characters from this text (excluding the user/hero). Return JSON list with name and a very short bio (10 words).
            Text: ${context}`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            name: { type: Type.STRING },
                            bio: { type: Type.STRING }
                        }
                    }
                }
            }
        });
        return JSON.parse(response.text || "[]");
      } catch {
          return [];
      }
  }
}

export const chatService = new ChatService();
