
import { EncryptedExport, ExportedSession } from '../types';

// Convert string to Uint8Array
const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder();

const strToUint8Array = (str: string) => textEncoder.encode(str);
const uint8ArrayToStr = (arr: Uint8Array) => textDecoder.decode(arr);

// Convert binary to Base64
const bufferToBase64 = (buffer: ArrayBuffer) => {
    return btoa(String.fromCharCode(...new Uint8Array(buffer)));
};

// Convert Base64 to binary
const base64ToBuffer = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
};

// Check if Crypto API is available
const checkCryptoAvailable = () => {
    if (!window.crypto || !window.crypto.subtle) {
        throw new Error("Web Crypto API is not available. Ensure you are using HTTPS or localhost.");
    }
};

// Derive key from password using PBKDF2
const getKeyFromPassword = async (password: string, salt: Uint8Array, type: 'encrypt' | 'decrypt'): Promise<CryptoKey> => {
    checkCryptoAvailable();
    const keyMaterial = await window.crypto.subtle.importKey(
        "raw",
        strToUint8Array(password),
        { name: "PBKDF2" },
        false,
        ["deriveKey"]
    );

    return window.crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: salt,
            iterations: 100000,
            hash: "SHA-256"
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        false,
        [type]
    );
};

export const encryptData = async (data: any, password: string): Promise<EncryptedExport> => {
    checkCryptoAvailable();
    try {
        const salt = window.crypto.getRandomValues(new Uint8Array(16));
        const iv = window.crypto.getRandomValues(new Uint8Array(12));
        const key = await getKeyFromPassword(password, salt, 'encrypt');
        
        const jsonString = JSON.stringify(data);
        const encodedData = strToUint8Array(jsonString);

        const encryptedBuffer = await window.crypto.subtle.encrypt(
            { name: "AES-GCM", iv: iv },
            key,
            encodedData
        );

        return {
            isEncrypted: true,
            data: bufferToBase64(encryptedBuffer),
            iv: bufferToBase64(iv),
            salt: bufferToBase64(salt),
            timestamp: Date.now()
        };
    } catch (e) {
        console.error("Encryption failed", e);
        throw e;
    }
};

export const decryptData = async (encrypted: EncryptedExport, password: string): Promise<ExportedSession> => {
    checkCryptoAvailable();
    try {
        const salt = new Uint8Array(base64ToBuffer(encrypted.salt));
        const iv = new Uint8Array(base64ToBuffer(encrypted.iv));
        const dataBuffer = base64ToBuffer(encrypted.data);

        const key = await getKeyFromPassword(password, salt, 'decrypt');

        const decryptedBuffer = await window.crypto.subtle.decrypt(
            { name: "AES-GCM", iv: iv },
            key,
            dataBuffer
        );

        const decryptedString = uint8ArrayToStr(new Uint8Array(decryptedBuffer));
        return JSON.parse(decryptedString);
    } catch (e) {
        console.error("Decryption failed", e);
        throw new Error("كلمة المرور خاطئة أو الملف تالف");
    }
};
